
package ifelseswitchingloopingbreakcontinue;

public class IfelseSwitchingLoopingBreakContinue {

    
    public static void main(String[] args) {
        
        System.out.println("Nilai dari setiap variabel");
        System.out.println("int x = 6       int minggu = 0  int kamis = 4");
        System.out.println("int y = 8       int senin  = 1  int jumat = 5");
        System.out.println("int z = 10      int selasa = 2  int sabtu = 6");
        System.out.println("                int rabu   = 3");
        
        int x = 6;                  int minggu = 0; int kamis = 4;
        int y =  8;                 int senin  = 1; int jumat = 5;
        int z = 10;                 int selasa = 2; int sabtu = 6;
                                    int rabu   = 3;
                                    
        System.out.println("Jika x lebih kecil dari y, dan jika y lebih kecil dari z, maka pernyataan yang benar adalah?");
        if(x > y) {//jika x lebih besar dari y
            System.out.println("X lebih besar dari Y"); //maka eksekusi perintah
        }   else if(y > z) { //jika tidak, maka jika y lebih besar dari z
                 System.out.println("Y lebih besar dari Z"); //maka eksekusi perintah
            
            } else if(z > x) { //jika tidak, maka jika z lebih besar dari x
                    System.out.println("Z lebih besar dari X"); //maka eksekusi perintah
                }  
        
        
        System.out.println("Hari apa yang kamu pilih?");
        switch(selasa) { //rubah isi untuk memilih salah satu pernyatan
            case  0: //pernyataan 1
                System.out.println("Saya memilih hari minggu");
                break; // break menandakan batas penghentian eksekusi kode
            case  1: //pernyataan 2
                System.out.println("Saya memilih hari senin");
                break;
            case  2: //pernyataan 3 dst
                System.out.println("Saya memilih hari selasa");
                break;
            case  3:
                System.out.println("Saya memilih hari rabu");
                break;
            case  4:
                System.out.println("Saya memilih hari kamis");
                break;
            case  5:
                System.out.println("Saya memilih hari jum'at");
                break;
            case  6:
                System.out.println("Saya memilih hari sabtu");
                break;
            default: System.out.println("Saya belum tahu"); //jika tidak ketemu nomor pernyataan maka default lah yang di eksekusi
        }
        
        
        System.out.println("Jika x lebih kecil dari y maka tambahkan nilai ");
        while(x < y) { //setiap x lebih kecil dari y 
            System.out.println(x);
            x++; //otomatis menambahkan 1 pada x
            break;
        }
        
        
     /*  do {
            System.out.println(y);
            y++;
            
        }
        while(y>x); */
        System.out.println("Setiap variabel a yang memiliki angka lebih besar dari z maka kurangi");
        for(int a = 18; a>z; a = a - 1) { //untuk setiap variabel a, jika a lebih besar dari z, maka a yaitu hasil dari a  - 1
            if(a==15){
            continue; //melanjutkan perintah setelah kondisi yang ditentukan
            }
            System.out.println(a);
        }
        
       
        
        
    }
}